<?php

class SLMS_Course_Price {

    public static function init(){
        add_filter('stm_wpcfto_fields', array(self::class, 'wpcfto_fields'), 15);
        add_action('admin_head', array(self::class, 'add_css'));
//        add_filter('stm_lms_course_price', array($this, 'course_price'), 15);
        add_filter('slms_course_price', array(self::class, 'get_price'), 15);
    }

    public static function wpcfto_fields($fields){

        $old_settings_fields = $fields['stm_courses_settings']['section_accessibility']['fields'];

        $new_settings_fields = array(
            'prices_list' => array(
                'type'  => 'repeater',
                'label' => esc_html__( 'Prices', 'slms' ),
                'fields' => array(
                    'country' => array(
                        'type'  => 'select',
                        'label' => esc_html__( 'Country', 'slms' ),
                        'options' => slms_get_countries()
                    ),
                    'price' => array(
                        'type'  => 'number',
                        'label' => esc_html__( 'Price', 'slms' )
                    )
                )
            ),
        );

        $fields['stm_courses_settings']['section_accessibility']['fields'] = array_merge($new_settings_fields, $old_settings_fields);

        return $fields;
    }

    public static function get($post_id = 0){
        $post_id = (empty($post_id)) ? get_the_ID() : $post_id;
        $countrycode = SLMS_IP_Info::get_ip_info(null, 'countrycode', true);
        $prices_list = get_post_meta($post_id, 'prices_list', true);
        $prices_list = (!empty($prices_list)) ? json_decode($prices_list, true) : [];

        if(count($prices_list)) {
            foreach ($prices_list as $item) {
                if($item['country'] == $countrycode) {
                    return $item['price'];
                }
            }
        }

        return STM_LMS_Course::get_course_price( $post_id );
    }

//    public static function course_price($post_id, $price){
//        $countrycode = SLMS_IP_Info::get_ip_info(null, 'countrycode', true);
//        $prices_list = get_post_meta(get_queried_object_id(), 'prices_list', true);
//        $prices_list = (!empty($prices_list)) ? json_decode($prices_list, true) : [];
//
//        if(count($prices_list)) {
//            foreach ($prices_list as $item) {
//                if($item['country'] == $countrycode) {
//                    return $item['price'];
//                }
//            }
//        }
//
//        return $price;
//    }

    public static function add_css(){
    ?>
        <style>
            .wpcfto-box-repeater.prices_list .wpcfto-repeater-single {
                margin: 0 0 1.5rem;
            }
            .wpcfto-box-repeater.prices_list .wpcfto-repeater-single .repeater_inner {
                display: flex;
                column-gap: 20px;
            }
            .wpcfto-box-repeater.prices_list .wpcfto-repeater-single .repeater_inner .wpcfto-repeater-field {
                margin: 0 0 15px;
            }
        </style>
    <?php
    }

}

SLMS_Course_Price::init();